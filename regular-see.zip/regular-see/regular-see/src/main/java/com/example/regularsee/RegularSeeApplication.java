package com.example.regularsee;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.File;
import java.nio.file.Files;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@SpringBootApplication
@RestController

public class RegularSeeApplication {

	private final Map<String,SseEmitter> sses=new ConcurrentHashMap<>();

	@Bean
	IntegrationFlow inboundFlow(@Value("${input-dir:file://${Home}/Desktop/in")File in)
	{
		return IntegrationFlows.from()
	}

	@GetMapping("/files/{name}")
	SseEmitter files(@PathVariable String name)
	{
		SseEmitter sseEmitter=new SseEmitter(60*1000L);
		sses.put(name,sseEmitter);
	}

	public static void main(String[] args) {
		SpringApplication.run(RegularSeeApplication.class, args);
	}
}
